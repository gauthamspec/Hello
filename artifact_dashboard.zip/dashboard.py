from flask import Flask, render_template
import csv

app = Flask(__name__)

@app.route("/")
def index():
    data = []
    with open("logs/artifact-download-log.csv", newline="") as csvfile:
        reader = csv.reader(csvfile)
        for row in reader:
            if row:  # skip empty rows
                data.append(row)
    return render_template("index.html", data=data)
