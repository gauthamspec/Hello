# Bitbucket Data Center Repo Pattern Scanner

## 🔍 Description
Scans **all projects** and **all repositories** in a Bitbucket Data Center instance for specific patterns across given branches.

## 🛠 Setup

1. Install dependencies:
```
pip install -r requirements.txt
```

2. Copy `.env.example` to `.env` and fill in your details.

3. Run the scanner:
```
python scanner_datacenter.py
```

4. Results are saved to `matched_patterns.csv`.

## 📄 .env Format
```
BITBUCKET_URL=http://bitbucket.mycompany.com
BITBUCKET_USER=myusername
BITBUCKET_TOKEN=mytoken
BRANCHES=main,develop,release/*
```