import os
import re
import csv
import shutil
import requests
import subprocess
from dotenv import load_dotenv

load_dotenv()

BASE_URL = os.getenv("BITBUCKET_URL")
USERNAME = os.getenv("BITBUCKET_USER")
PASSWORD = os.getenv("BITBUCKET_TOKEN")
BRANCHES = os.getenv("BRANCHES", "").split(",")

PATTERNS = [
    r"de\.kordoba\.legacy\.jci",
    r"de\.kordoba\.framework\.legacy\:korframework",
    r"de\.kordoba\.framework\.legacy\:korwelframework",
    r"de\.kordoba\.framework\.legacy\:korconfigurator",
    r"de\.kordoba\.framework\.common\.legacy\:korlogger",
    r"de\.kordoba\.framework\.crypto\.legacy\:kordecrypt",
    r"de\.kordoba\.framework\.common\.legacy\:korparametertables"
]

CSV_FILE = "matched_patterns.csv"
CLONE_DIR = "./tmp_repos"

def run_cmd(cmd, cwd=None):
    result = subprocess.run(cmd, cwd=cwd, stdout=subprocess.PIPE, stderr=subprocess.PIPE, shell=True, text=True)
    return result.stdout.strip()

def get_projects():
    print("🔍 Fetching all projects...")
    projects = []
    url = f"{BASE_URL}/rest/api/1.0/projects?limit=100"
    while url:
        r = requests.get(url, auth=(USERNAME, PASSWORD), verify=False)
        r.raise_for_status()
        data = r.json()
        for proj in data["values"]:
            projects.append(proj["key"])
        url = data.get("nextPageStart")
        if url:
            url = f"{BASE_URL}/rest/api/1.0/projects?limit=100&start={url}"
    return projects

def get_repos(project_key):
    repos = []
    url = f"{BASE_URL}/rest/api/1.0/projects/{project_key}/repos?limit=100"
    while url:
        r = requests.get(url, auth=(USERNAME, PASSWORD), verify=False)
        r.raise_for_status()
        data = r.json()
        for repo in data["values"]:
            repos.append(repo["slug"])
        url = data.get("nextPageStart")
        if url:
            url = f"{BASE_URL}/rest/api/1.0/projects/{project_key}/repos?limit=100&start={url}"
        else:
            url = None
    return repos

def get_repo_branches(project_key, repo_slug):
    branches = []
    url = f"{BASE_URL}/rest/api/1.0/projects/{project_key}/repos/{repo_slug}/branches?limit=100"
    while url:
        r = requests.get(url, auth=(USERNAME, PASSWORD), verify=False)
        r.raise_for_status()
        data = r.json()
        for branch in data["values"]:
            branches.append(branch["displayId"])
        url = data.get("nextPageStart")
        if url:
            url = f"{BASE_URL}/rest/api/1.0/projects/{project_key}/repos/{repo_slug}/branches?limit=100&start={url}"
        else:
            url = None
    return branches

def clone_repo(project_key, repo_slug, branch):
    repo_dir = f"{CLONE_DIR}/{project_key}_{repo_slug}_{branch.replace('/', '_')}"
    if os.path.exists(repo_dir):
        shutil.rmtree(repo_dir)
    repo_url = f"{BASE_URL}/scm/{project_key}/{repo_slug}.git"
    clone_cmd = f"git clone -b {branch} --single-branch https://{USERNAME}:{PASSWORD}@{repo_url[8:]} {repo_dir}"
    run_cmd(clone_cmd)
    return repo_dir

def search_patterns(filepath):
    matches = []
    try:
        with open(filepath, 'r', encoding='utf-8', errors='ignore') as f:
            for num, line in enumerate(f, 1):
                for pattern in PATTERNS:
                    if re.search(pattern, line):
                        matches.append((num, line.strip(), pattern))
    except Exception:
        pass
    return matches

def scan_repo(project, repo, branch):
    results = []
    path = clone_repo(project, repo, branch)
    for root, _, files in os.walk(path):
        for file in files:
            if file.endswith(('.java', '.gradle', '.xml', '.properties', '.txt')):
                full_path = os.path.join(root, file)
                for lineno, linetext, pattern in search_patterns(full_path):
                    results.append({
                        "Project": project,
                        "Repo": repo,
                        "Branch": branch,
                        "File": os.path.relpath(full_path, path),
                        "Line Number": lineno,
                        "Matched Pattern": pattern,
                        "Line Text": linetext
                    })
    shutil.rmtree(path)
    return results

def main():
    os.makedirs(CLONE_DIR, exist_ok=True)
    all_results = []
    projects = get_projects()
    for project in projects:
        repos = get_repos(project)
        for repo in repos:
            repo_branches = get_repo_branches(project, repo)
            for branch in repo_branches:
                if any(branch == b or (b.endswith("*") and branch.startswith(b[:-1])) for b in BRANCHES):
                    print(f"🔎 Scanning {project}/{repo} [{branch}]")
                    all_results.extend(scan_repo(project, repo, branch))
    with open(CSV_FILE, 'w', newline='', encoding='utf-8') as f:
        writer = csv.DictWriter(f, fieldnames=["Project", "Repo", "Branch", "File", "Line Number", "Matched Pattern", "Line Text"])
        writer.writeheader()
        writer.writerows(all_results)
    print(f"✅ Done. Results saved to {CSV_FILE}")

if __name__ == "__main__":
    main()